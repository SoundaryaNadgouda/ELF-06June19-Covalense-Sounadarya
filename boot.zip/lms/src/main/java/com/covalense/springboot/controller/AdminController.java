package com.covalense.springboot.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.springboot.dto.Response;
import com.covalense.springboot.dto.UserBean;

import com.covalense.springboot.repository.BookRepository;
import com.covalense.springboot.repository.UserRepository;

@CrossOrigin("http://localhost:3000")
@RequestMapping("/user")
@RestController
public class AdminController {
	

	@Autowired
	UserRepository userRepository;
	
	
	@PostMapping(path = "/addUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response createUser(@RequestBody UserBean user, HttpServletRequest request) {
		Response response = new Response();
		
		//user.setPassword(user.getFirstName().substring(0,3)+(int)(Math.random()*99999));
		user.setUserStatus("active");
		if (request.getSession(false) != null) {
			//UserBean userBean=userRepository.save(user);
			userRepository.save(user);
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBeans(Arrays.asList(user));
			response.setDescription("User Added Successfully");
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
	}

	
	@PutMapping(path="/updateUser",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response updateUser(@RequestBody UserBean user, HttpServletRequest request) {
		Response response = new Response();

		if (request.getSession(false) != null) {
			if (userRepository.existsById(user.getUserId())) {
				//UserBean userBean=userRepository.save(user);
				userRepository.save(user);
				response.setMessage("success");
				response.setStatusCode(201);
				response.setBeans(Arrays.asList(user));
				response.setDescription("User Updated Successfully");
			} else {
				response.setMessage("failure");
				response.setStatusCode(501);
				response.setDescription("User not exist");
			}
			return response;
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
		
		
	}
	
	@PutMapping(path="/deactivateUser",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response deActivateUser(@RequestParam int id, HttpServletRequest request) {
		Response response = new Response();
		UserBean user = userRepository.findById(id).get();
		user.setUserStatus("deactive");
		if (request.getSession(false) != null) {
			userRepository.save(user);
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBeans(Arrays.asList(user));
			response.setDescription("User deleted Successfully");
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
	}
	
	@GetMapping(path="/searchByName", produces=MediaType.APPLICATION_JSON_VALUE)
	public Response searchUserByName(String name, HttpServletRequest request) {
		Response response = new Response();
		//if (request.getSession(false) != null) {
		List<UserBean> userList=(List<UserBean>) userRepository.findByFirstName(name);	
		if(userList.size() != 0) {
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBeans(userList);
			response.setDescription("Got all users Successfully");
		}else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("No user Found");
		}
		return response;
	}
	
	@GetMapping(path="/getAllUser",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response getAllUser(HttpServletRequest request) {
		Response response = new Response();
		if (request.getSession(false) != null) {
		List<UserBean> userList=(List<UserBean>) userRepository.findAll();	
		if(userList!=null) {
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBeans(userList);
			response.setDescription("Got all users Successfully");
		}else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("No user Found");
		}
		return response;
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
	}

}