package com.covalense.springboot.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.springboot.dto.Book;
import com.covalense.springboot.dto.Response;
import com.covalense.springboot.repository.BookRepository;


@CrossOrigin("http://localhost:3000")
@RestController
public class LibrarianController {
	
	@Autowired
	BookRepository bookRepository;
	
	@PostMapping(path="/addBook",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response addBookDetails(@RequestBody Book book, HttpServletRequest request) {
		Response response = new Response();
		if (request.getSession(false) != null) {
			Book book1 =bookRepository.save(book);
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBookBeans(Arrays.asList(book1));
			response.setDescription("Book Added Successfully");
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
	}
	
	
	@GetMapping(path="/getBook",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response getBookDetails(@RequestParam int id, HttpServletRequest request) {
		Response response = new Response();
		
		if (request.getSession(false) != null) {
			Book book=bookRepository.findById(id).get();
			if(book !=null) {
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBookBeans(Arrays.asList(book));
			response.setDescription("Got Book details Successfully");
			}else {
				response.setMessage("failure");
				response.setStatusCode(501);
				response.setDescription("No book available");
			}
			return response;
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login First");
		}
		return response;
	}

}