package com.covalense.springboot.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.covalense.springboot.dto.Book;


@Repository
public interface BookRepository extends CrudRepository<Book, Integer>{

}