package com.covalense.springboot.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.springboot.dto.Response;
import com.covalense.springboot.dto.UserBean;
import com.covalense.springboot.repository.UserRepository;


@CrossOrigin(origins="http://localhost:3000")
@RestController
public class LoginController {

	@Autowired
	UserRepository userRepository;
	
	@PostMapping(path="/login/authenticate",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response userLogin(String email, String password, HttpServletRequest request) {
		UserBean userBean = userRepository.findByEmail(email);
		Response response = new Response();
		if (userBean != null && userBean.getPassword().equals(password)) {
			response.setMessage("success");
			response.setStatusCode(201);
			response.setBeans(Arrays.asList(userBean));
			response.setDescription("Login Successfull");
			request.getSession().setAttribute("userBean", userBean);
		} else {
			response.setMessage("failure");
			response.setStatusCode(501);
			response.setDescription("Login Failed");
		}
		return response;
	}

	@GetMapping(path="/logout",produces=MediaType.APPLICATION_JSON_VALUE)
	public Response userLogout(HttpSession session) {
		Response response = new Response();
		session.invalidate();
		response.setMessage("success");
		response.setStatusCode(201);
		response.setDescription("Logout Successfull");
		return response;
	}

	
}