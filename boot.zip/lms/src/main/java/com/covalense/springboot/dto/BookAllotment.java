package com.covalense.springboot.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@SuppressWarnings("serial")

@Entity
@Table(name="book_allotment")
public class BookAllotment implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="book_allotment_id")
	private int bookAllotmentId;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private UserBean userId;
	
	@ManyToOne
	@JoinColumn(name="book_id")
	private Book bookId;
	
	@Column(name="issue_date")
	private Date issueDate;
	@Column(name="return_date")
	private String returnDate;
	private String status;
	public int getBookAllotmentId() {
		return bookAllotmentId;
	}
	public void setBookAllotmentId(int bookAllotmentId) {
		this.bookAllotmentId = bookAllotmentId;
	}
	public UserBean getUserId() {
		return userId;
	}
	public void setUserId(UserBean userId) {
		this.userId = userId;
	}
	public Book getBookId() {
		return bookId;
	}
	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}