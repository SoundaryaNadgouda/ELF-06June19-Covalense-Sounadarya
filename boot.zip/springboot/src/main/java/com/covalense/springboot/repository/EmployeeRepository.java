package com.covalense.springboot.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.covalense.springboot.dto.EmpInfoBean;
import com.covalense.springboot.dto.EmpOtherInfoBean;

public interface EmployeeRepository extends CrudRepository<EmpInfoBean, Integer>{

	@Query("Select e from EmpOtherInfoBean e where e.infoBean=:id")
	public EmpOtherInfoBean findByEmpId(@Param("id") EmpInfoBean id);
}
